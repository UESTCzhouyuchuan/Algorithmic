#include<stdio.h>

int main(void){
	int n;
	printf("Enter a number: \n");
	scanf(" %d",&n);             //��ȡn 
	printf("sum=%d\n",n*(n+1)/2); 
}
